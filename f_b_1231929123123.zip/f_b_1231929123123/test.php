<html lang="en"><head>
    <title>Free TikTok Followers</title>
<meta name="description" content="TikTok Followers Generator 2021 ">
<meta property="og:title" content="TikTok Followers Generator 2021 ">
<meta property="og:description" content="TikTok Followers Generator 2021 ">
<meta name="referrer" content="no-referrer">

<!-- Analytics -->
<script async="" src="https://www.google-analytics.com/analytics.js"></script><script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

    
    
    ga('send', 'pageview');

</script>
<script src="https://browser.sentry-cdn.com/5.20.1/bundle.min.js" integrity="sha384-O8HdAJg1h8RARFowXd2J/r5fIWuinSBtjhwQoPesfVILeXzGpJxvyY/77OaPPXUo" crossorigin="anonymous"></script>
<script>
    Sentry.init({ dsn: 'https://ecc33db07c514172b5606edcabb2884e@o425163.ingest.sentry.io/5357949' });
</script>

    <style>
        .header_blue {
            background: #1565c0;
            padding: 80px 0 20px;
            color: #fff;
            font-size: 48px;
            font-weight: 300;
            margin-bottom: 40px;
        }
        .header_text {
            margin-left: auto;
            margin-right: auto;
            width: 80%;
        }
        body{
            margin:0;
            font-family:Roboto, sans-serif;
            color:#444;
              overflow-x: hidden;
        }
        .unlockBtn:hover{
            box-shadow: 0 3px 6px rgba(0,0,0,.16), 0 3px 6px rgba(0,0,0,.23);
        }
        .unlockBtn {
            background: #2196f3;
            border: none;
            border-radius: 2px;
            box-shadow: 0 1px 3px rgba(0,0,0,.12), 0 1px 2px rgba(0,0,0,.24);
            min-height: 31px;
            min-width: 70px;
            padding: 2px 16px;
            text-align: center;
            text-shadow: none;
            text-transform: uppercase;
            -webkit-transition: all 280ms ease;
            transition: all 280ms ease;
            box-sizing: border-box;
            cursor: pointer;
            -webkit-appearance: none;
            display: inline-block;
            vertical-align: middle;
            font: 500 14px/31px Roboto,sans-serif!important;
            outline: 0!important;
            color:white;
        }
        .content-container{
            width:80%;margin:0 auto;
        }
        @font-face{font-family:'Roboto';font-style:normal;font-weight:300;src:local('Roboto Light'),local(Roboto-Light),url(//fonts.gstatic.com/s/roboto/v15/Pru33qjShpZSmG3z6VYwnRJtnKITppOI_IvcXXDNrsc.woff2) format("woff2");unicode-range:U+0100-024F,U+1E00-1EFF,U+20A0-20AB,U+20AD-20CF,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:'Roboto';font-style:normal;font-weight:300;src:local('Roboto Light'),local(Roboto-Light),url(//fonts.gstatic.com/s/roboto/v15/Hgo13k-tfSpn0qi1SFdUfVtXRa8TVwTICgirnJhmVJw.woff2) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2212,U+2215,U+E0FF,U+EFFD,U+F000}@font-face{font-family:'Roboto';font-style:normal;font-weight:500;src:local('Roboto Medium'),local(Roboto-Medium),url(//fonts.gstatic.com/s/roboto/v15/oOeFwZNlrTefzLYmlVV1UBJtnKITppOI_IvcXXDNrsc.woff2) format("woff2");unicode-range:U+0100-024F,U+1E00-1EFF,U+20A0-20AB,U+20AD-20CF,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:'Roboto';font-style:normal;font-weight:500;src:local('Roboto Medium'),local(Roboto-Medium),url(//fonts.gstatic.com/s/roboto/v15/RxZJdnzeo3R5zSexge8UUVtXRa8TVwTICgirnJhmVJw.woff2) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2212,U+2215,U+E0FF,U+EFFD,U+F000}
        body{
  font-family: Poppins;

}
h1{
  font-weight: bold;
}
.header {
  text-align: left;
  position: fixed;
  width: 100%;
  background: #fff;
  color: #474747;
  box-shadow: 0 0 5px black;

padding: 15px;
z-index: 1;
top: 0;
left: 0;
}
.text-enter-username{
  position: relative;
  color: #474747;
  font-family: Poppins;
  font-weight: bold;
  font-size: 32px;
  padding: 5px;

}
.title{
  text-align: center;
  width: 100%;
margin-top: 120px;
  color: #474747;
  font-family: Poppins;
  font-weight: bold;
  font-size: 22px;
  padding: 5px;
}
.usernamebox1{
  text-align: center;
  align-items: center;
  justify-content: center;
  position: relative;
  margin-top: 50px;
  max-width: 600px;
  width: 90%;
height: auto;
overflow: auto;
padding-bottom: 20px;
background-color: white;
border-radius: 30px;
box-shadow: 0 0 10px #cfcfcf;
margin-bottom: 200px;
}
.footer{
  align-items: center;
  justify-content: center;
  text-align: center;
  display: flex;
}
.footer1{
  align-items: center;
  justify-content: center;
  text-align: center;
padding: 10px;
  position: fixed;
bottom: 20px;
width: 80%;
height: 80px;
background-color:  #fafafa;
border-radius: 20px;
z-index: 1;
   box-shadow:  0px 2px 4px 2px #ccc;
}
.footertext{
  color: #000;
margin: 0px;

}
.footerleft{
position: fixed;
bottom: 20px;
width: 80%;
margin-left: -30px;
height: 100px;
background-color: none;
border-radius: 20px;

}
.footerright{
position: fixed;
bottom: 20px;
width: 80%;
margin-right: -30px;
height: 100px;
background-color: none;
border-radius: 20px;


}
img.imgtiktok{
   width:80px;
  margin-top:10px;
}
img.imguser{
  width:100px;
  top: 10px;
padding: 10px;
}
input{
  color: #474747;
  position: relative;

  border: 2px solid #2ff1ff;
  border-radius: 30px;
}
input[type=text] {

  width: 250px;
  box-sizing: border-box;
  border: 2px solid #82eae5;
  border-radius: 30px;
  font-size: 30px;
  font-weight: bold;
  background-color: white;
background-image: url("https://d13pxqgp3ixdbh.cloudfront.net/uploads/1605495763d34e91a02f3ce93e6e6f7d245e5694bb.png");
background-size: 39px;
  background-position: 10px 10px;
  background-repeat: no-repeat;
  padding: 12px 20px 12px 50px;
  transition: width 0.4s ease-in-out;
  box-shadow: 0 0 4px #00f7ef;
}

input[type=text]:focus {
  outline: none;
  width: 400px;
box-sizing: border-box;
border: 2px solid #2fffee;
border-radius: 30px;
font-size:30px;
background-color: white;
transition: width 0.4s ease-in-out;
box-shadow: 0 0 4px #00f7ef;
}
.bntValidate{
  margin-top: 20px;
  border-style: solid;
  border-radius: 5px;
  border-width: 2px;
  border-color: #4ecdff;
  box-shadow: 0 0 2px #00c7c0;
  justify-content: center;
  align-items: center;
  color: white;
  font-size: 28px;
  display: flex;
  position: relative;
  background-color: #00d9ff;
  width: 250px;
  height: 60px;
}
.bntValidate:hover{
  box-shadow: 0 0 10px #00c7c0;
  cursor: pointer;
}
.line{

  top:180px;
  height: 2px;
  width: 80%;
  background-color:#c4c5c9;
}


.packag1:hover{
  cursor: pointer;
  animation:shadow-drop-2-center .4s cubic-bezier(.25,.46,.45,.94) both
}
.packag2:hover{
  cursor: pointer;
  animation:shadow-drop-2-center .4s cubic-bezier(.25,.46,.45,.94) both
}
.packag3:hover{
  cursor: pointer;
  animation:shadow-drop-2-center .4s cubic-bezier(.25,.46,.45,.94) both
}
.packag1{
  margin-top: 10px;
  text-align: center;
  box-shadow: 0 0 10px #c2c2c2;
  height: 120px;
        width: 90%;
      background-color: white;
      text-align: center;
      border-radius: 10px;
      border-style: solid;
      border-width: 2px;
      border-color: #ebebeb;
position: relative;


}

.selectedpackage{
  text-align: center;
  box-shadow: 0 0 10px #c2c2c2;
      height: 120px;
      width: 90%;
      background-color: white;
      border-radius: 10px;
      border-style: solid;
      border-width: 1px;
      border-color: #ebebeb;

}
.packag2{
margin-top: 10px;
margin-bottom: 10px;
  text-align: center;
  box-shadow: 0 0 10px #c2c2c2;
      height: 120px;
        width: 90%;
      background-color: white;
      text-align: center;
      border-radius: 10px;
      border-style: solid;
      border-width: 1px;
      border-color: #ebebeb;
position: relative;
}
.packag3{
  text-align: center;
  box-shadow: 0 0 10px #c2c2c2;
      height: 120px;
      width: 90%;
      background-color: white;
      text-align: center;
      border-radius: 10px;
      border-style: solid;
      border-width: 1px;
      border-color: #ebebeb;
position: relative;

}

.cardtext{
  padding: 0px;
  margin: 0px;
  font-weight: bolder;
}

.text-gen{
   color: #474747;
    font-family: Poppins;
    font-weight: bold;
    font-size: 22px;
    padding: 5px;
}


.loader{
  display: none;
width:50px;
position: relative;
padding-top:20px;
margin-top: 10px;
left: 50%;
margin-left: -20px;
}
.loaderblue{
  position: absolute;
  left: 0px;
  width:20px;
  height: 20px;
  background-color:#00f7efbf ;
  border-radius: 50%;
  animation-name: loaderblue;
  animation-duration: 1s;
  animation-iteration-count: infinite;
}
.loaderred{
  position: absolute;
  left: 20px;
  width:20px;
  height: 20px;
  background-color:#2fe7ffba;
  border-radius: 50%;
  animation-name: loaderred;
  animation-duration: 1s;
  animation-iteration-count: infinite;
}

@keyframes loaderblue {
  0%   {background-color:#00f7efbf; left:0px; top:0px;width:20px;height:20px;z-index: 1;}
  50% {background-color:#00f7efbf; left:20px; top:0px;width:20px;height:20px;z-index: 1;}
  75% {background-color:#00f7efbf; left:10px; top:2px;width:15px;height:15px;z-index: 0;}
  100% {background-color:#00f7efbf; left:0px; top:0px;width:20px;height:20px;z-index: 0;}
}
@keyframes loaderred {
  0%   {background-color:#2ffff5ba; left:20px; top:0px;width:20px;height:20px;z-index: 1;}
  25% {background-color:#2ffff5ba; left:10px; top:2px;width:15px;height:15px;z-index: 0;}
  50% {background-color:#2ffff5ba; left:0px; top:0px;width:20px;height:20px;z-index: 0;}
  100% {background-color:#2ffff5ba; left:20px; top:0px;width:20px;height:20px;z-index: 1;}
}


@keyframes shadow-drop-2-center{0%{transform:translateZ(0);box-shadow:0 0 0 0 transparent}100%{transform:translateZ(50px);box-shadow:0 0 20px 0 rgba(0,0,0,.35)}}



@media only screen and (max-width:680px) {
  .text-enter-username{
    position: relative;
    color: #474747;
    font-family: Poppins;
    font-weight: bold;
    font-size: 24px;
    padding: 5px;

  }
  .header {
    text-align: center;
    position: fixed;
    width: 100%;
    background: #fff;
    color: #474747;
    box-shadow: 0 0 5px black;
    padding: 10px;
   z-index: 1;
   top: 0;
   left: 0;
  }


  input[type=text]:focus {
    outline: none;
    width: 300px;
  box-sizing: border-box;
  border: 2px solid #2ffff5ba;
  border-radius: 30px;
  font-size:30px;
  background-color: white;
  transition: width 0.4s ease-in-out;
  box-shadow: 0 0 4px #00f7ef;
  }

}

    </style>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<script type="text/javascript" src="https://d2punpeg7vtjci.cloudfront.net/public/external/v2/html.1153885.d2f29.0.js" id="CPABUILDMAINJS"></script><link rel="stylesheet" href="https://d2punpeg7vtjci.cloudfront.net/public/external/css_front.css" id="CPABUILDGLOBALSTYLE"><link data-it="1153885" rel="stylesheet" id="CPABUILDSPECIFICSTYLE" href="https://d2punpeg7vtjci.cloudfront.net/public/clockers/CustomButton/css.css"><style type="text/css" id="CPABUILDSettingsCSS">#CPABUILD_MODAL_CONTAINER #CPABUILDMODALCONTENT{animation-duration: 600ms;-webkit-transition: all 600ms;transition: all 600ms;transition-duration: 600ms;}#CPABUILD_MODAL_CONTAINER #CPABUILD_MODAL {background-color: rgba(0,0,0,0.4) }</style><script type="text/javascript" src="https://d2punpeg7vtjci.cloudfront.net/public/guid?cpguid=97w24vc90&amp;e=ll&amp;t=1677957597607"></script><script id="CPABUILDLEADCHECK" type="text/javascript" src="https://d2punpeg7vtjci.cloudfront.net/public/external/check.php?it=1153885&amp;time=1677958647674"></script></head>
<body>



  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" type="text/css" href="style.css">
  <title>TikTok Followers Generator Tools</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">


    <center>
<div class="header" id="myHeader">
  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSL6wVKRiAC2KTazQ4wyZkEjgKMRhMdF2D55fp9rpBZjMJ5EKwoQIeer5jEcVosvVBCa3c&amp;usqp=CAU" style="width:25px"><img src="https://i.imgur.com/e4vj3HA.png" style="width:100px">
  
</div>
<br>
<br>
<br>

<div class="usernamebox1" id="screen1">

<img src="warningicon.png" class="imgtiktok" style="
    width: 25px;
">
<div class="text-enter-username" style="
    font-family: inherit;
    font-size: 1.5rem;
    line-height: 1.1667;
    font-weight: 700;
    min-width: 0;
">You disagreed with the decision</div>
  
<center>
<p id="date"></p>
    <script>// Get the current date
const currentDate = new Date();

// Create an array of month names
const months = [
	"January",
	"February",
	"March",
	"April",
	"May",
	"June",
	"July",
	"August",
	"September",
	"October",
	"November",
	"December"
];

// Get the month name and day of the month
const monthName = months[currentDate.getMonth()];
const dayOfMonth = currentDate.getDate();

// Create the date string in the desired format
const dateString = `ON ${monthName} ${dayOfMonth}, ${currentDate.getFullYear()}`;

// Update the HTML element with the date string
document.getElementById("date").textContent = dateString;</script>


    
</center><hr style="
    width: 32rem;
    border-top-color: var(--divider);
">
<div class="loader" id="loader">
<div class="loaderblue" id="loaderblue"></div><div class="loaderred" id="loaderred"></div>
</div>

</div>
<div class="usernamebox1" id="screen2" style="display:none;">
<img src="https://d13pxqgp3ixdbh.cloudfront.net/uploads/1605495763d34e91a02f3ce93e6e6f7d245e5694bb.png" class="imguser">
<div style="padding:20px;  color: #474747;
  font-family: Poppins;
  font-weight: bold;
  font-size: 20px;
  padding: 5px;">Username: <span id="username1">cpabuild</span></div>
<center><div class="line"></div></center>
<div class="text-enter-username">Select number of followers</div>
<center><div class="packag1" onclick="package(1)"><img src="https://cdn-icons-png.flaticon.com/512/747/747835.png" style="width:40px;margin-top:10px;"><p class="cardtext">1,000</p><p class="cardtext">FOLLOWERS</p></div>
<div class="packag2" onclick="package(2)"><img src="https://cdn-icons-png.flaticon.com/512/747/747835.png" style="width:40px;margin-top:10px;"><p class="cardtext">2,500</p><p class="cardtext">FOLLOWERS</p></div>
<div class="packag3" onclick="package(3)"><img src="https://cdn-icons-png.flaticon.com/512/747/747835.png" style="width:40px;margin-top:10px;"><p class="cardtext">5,000</p><p class="cardtext">FOLLOWERS</p></div>
</center>

<div class="loader" id="loader">
<div class="loaderblue" id="loaderblue"></div><div class="loaderred" id="loaderred"></div>
</div>

</div>
<div class="usernamebox1" id="screen3" style="display:none;">
<img src="https://d13pxqgp3ixdbh.cloudfront.net/uploads/1605495763d34e91a02f3ce93e6e6f7d245e5694bb.png" class="imguser">
<div style=" padding-top:10px;  color: #474747;
  font-family: Poppins;
  font-weight: bold;
  font-size: 20px;
  padding: 5px;">Username: <span id="username">@username</span></div>
<center><div class="line"></div></center>
<div class="loader" id="loader2">
<div class="loaderblue" id="loaderblue"></div><div class="loaderred" id="loaderred"></div>
</div>
<div class="text-gen" id="processing">Select number of followers</div>

<center><div class="selectedpackage"><img src="https://cdn-icons-png.flaticon.com/512/747/747835.png" style="width:40px;margin-top:10px;"><p class="cardtext" id="followGen">+0</p><p class="cardtext">FOLLOWERS</p></div></center>
<div id="highttraffic" style="display: none;color:#474747;font-size:22px;font-weight:bold;padding-top:10px;">Unusually high traffic from</div>
<div id="verifyrequired" style="display: none;color:#ffbb0f;font-size:22px;font-weight:bold;padding-top:10px;">Human Verification Required</div>
<center><div class="bntValidate" onclick="CPABuildLock()" id="verify" style="display:none">Verify Now</div></center>
</div>
<div class="footer">



</div>


</center>
<script src="main.js"></script>
<script>(function(){var js = "window['__CF$cv$params']={r:'7a2c7936ed0bcf40',m:'jtJiqlszi3vP8fdmm3y4K_BxCHvwKVCDTelecQDo9mg-1677957594-0-AU6WJNPmS9AufxaB5p5f/TBWNgPUtIV/4dQkMSCiMjb23rDAhTbF1cGme2tBs7a4pRwCUmSmXYKgsd9ek2F/FOaGo5zDBZghYo3bReg83oO/PVnCP+V82GHBCvxTLgj9NqzTqiEDHDegRqdnB1uLoVrnu7f1L/Q74S0JbDz/Ggqb',s:[0x80bb148f34,0x7f64f3eaa3],u:'/cdn-cgi/challenge-platform/h/g'};var now=Date.now()/1000,offset=14400,ts=''+(Math.floor(now)-Math.floor(now%offset)),_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='/cdn-cgi/challenge-platform/h/g/scripts/alpha/invisible.js?ts='+ts,document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.nonce = '';_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();</script><iframe height="1" width="1" style="position: absolute; top: 0px; left: 0px; border: none; visibility: hidden;"></iframe>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>


<div id="CPABUILD_MODAL_CONTAINER" style="display: none;"><div id="CPABUILD_MODAL">
    <div id="CPABUILDMODALCONTENT" class="CPABUILD_fadeIn">
        <div id="CPABUILDMODALHEADER">
            <div id="CPABUILDMODALTITLE"></div> </div>
        <div id="CPABUILDMODALBODY">
            <iframe id="CPABUILDOFFERS" style="overflow:hidden;" src=""></iframe>
        </div>
        <div id="CPABUILDMODALFOOTER">
            <p id="CPABUILDMODALFOOTERTEXT"></p>
        </div>
    </div>
</div>
</div></body></html>